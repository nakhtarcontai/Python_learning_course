from tkinter import *
import tkinter.messagebox as messagebox
# This is a simple calculator using Tkinter in Python
window = Tk()
window.title("Calculator")
window.geometry("500x500")
window.configure(bg="lightblue")

# Entry box
e = Entry(window, width=50, borderwidth=5)
e.place(x=10, y=10)

# Button functions
def button_click(number):
    result = e.get()
    e.delete(0, END)
    e1 = e.insert(0, str(result) + str(number))
    print(e1)
    print(result)
    print(e.get())

b1 = Button(window, text="1", width= 10, command=lambda: button_click(1))  
b1.place(x=10, y=50)
b2 = Button(window, text="2", width= 10, command=lambda: button_click(2))
b2.place(x=90, y=50)
b3 = Button(window, text="3", width= 10, command=lambda: button_click(3))
b3.place(x=170, y=50)
b4 = Button(window, text="4", width= 10, command=lambda: button_click(4))
b4.place(x=10, y=80)
b5 = Button(window, text="5", width= 10, command=lambda: button_click(5))
b5.place(x=90, y=80)    
b6 = Button(window, text="6", width= 10, command=lambda: button_click(6))
b6.place(x=170, y=80)
b7 = Button(window, text="7", width= 10, command=lambda: button_click(7))
b7.place(x=10, y=110)
b8 = Button(window, text="8", width= 10, command=lambda: button_click(8))
b8.place(x=90, y=110)
b9 = Button(window, text="9", width= 10, command=lambda: button_click(9))
b9.place(x=170, y=110)
b0 = Button(window, text="0", width= 10, command=lambda: button_click(0))
b0.place(x=10, y=140)

# Placeholder functions for operations
# addition
def button_add():
    n1 =e.get()
    print(n1)
    global math
    math = "addition"
    global i
    i = int(n1)
    e.delete(0, END)
b_plus = Button(window, text="+", width= 10, command= button_add)
b_plus.place(x=90, y=140)
# subtraction
def button_subtract():
    n1 =e.get()
    global math
    math = "subtraction"
    global i
    i = int(n1)
    e.delete(0, END)
b_minus = Button(window, text="-", width= 10, command= button_subtract)
b_minus.place(x=170, y=140)
# multiplication
def button_multiply():
    n1 =e.get()
    global math
    math = "multiplication"
    global i
    i = int(n1)
    e.delete(0, END)
b_multiply = Button(window, text="*", width= 10, command= button_multiply)
b_multiply.place(x=10, y=170)
# division
def button_divide():
    n1 =e.get()
    global math
    math = "division"
    global i
    i = int(n1)
    e.delete(0, END)
b_divide = Button(window, text="/", width= 10, command= button_divide)
b_divide.place(x=90, y=170)
# equal
def button_equal():
    n2 =e.get()
    print(n2)
    e.delete(0, END)
    if math == "addition":
        e.insert(0, i + int(n2))
    if math == "subtraction":
        e.insert(0, i - int(n2))
    if math == "multiplication":
        e.insert(0, i * int(n2))
    if math == "division":
        try:
            e.insert(0, i / int(n2))
        except ZeroDivisionError:
            messagebox.showerror("Error", "Cannot divide by zero")
            e.delete(0, END)
            return
b_equal = Button(window, text="=", width= 10, command= button_equal)
b_equal.place(x=170, y=170)
# clear
def button_clear():
    e.delete(0, END)
b_clear = Button(window, text="Clear", width= 10,  command= button_clear)
b_clear.place(x=10, y=200)



mainloop() 