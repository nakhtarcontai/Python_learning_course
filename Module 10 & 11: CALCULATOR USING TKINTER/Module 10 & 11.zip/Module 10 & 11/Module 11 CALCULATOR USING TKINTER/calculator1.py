from tkinter import *

window = Tk()
window.title("Calculator")
window.geometry("500x500")

# Entry box
e = Entry(window, width=50, borderwidth=5)
e.place(x=10, y=10)

# Button functions
b1 = Button(window, text="1", width= 10)  
b1.place(x=10, y=50)
b2 = Button(window, text="2", width= 10)
b2.place(x=90, y=50)
b3 = Button(window, text="3", width= 10)
b3.place(x=170, y=50)
b4 = Button(window, text="4", width= 10)
b4.place(x=10, y=80)
b5 = Button(window, text="5", width= 10)
b5.place(x=90, y=80)    
b6 = Button(window, text="6", width= 10)
b6.place(x=170, y=80)
b7 = Button(window, text="7", width= 10)
b7.place(x=10, y=110)
b8 = Button(window, text="8", width= 10)
b8.place(x=90, y=110)
b9 = Button(window, text="9", width= 10)
b9.place(x=170, y=110)
b0 = Button(window, text="0", width= 10)
b0.place(x=10, y=140)
b_plus = Button(window, text="+", width= 10)
b_plus.place(x=90, y=140)
b_minus = Button(window, text="-", width= 10)
b_minus.place(x=170, y=140)
b_multiply = Button(window, text="*", width= 10)
b_multiply.place(x=10, y=170)
b_divide = Button(window, text="/", width= 10)
b_divide.place(x=90, y=170)
b_equal = Button(window, text="=", width= 10)
b_equal.place(x=170, y=170)
b_clear = Button(window, text="Clear", width= 10)
b_clear.place(x=10, y=200)























mainloop() 