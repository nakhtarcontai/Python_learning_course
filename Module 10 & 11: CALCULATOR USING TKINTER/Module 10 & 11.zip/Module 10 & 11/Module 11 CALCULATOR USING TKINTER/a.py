from tkinter import *

window = Tk()
window.title("Calculator")
window.geometry("500x500")

# Entry box
e = Entry(window, width=50, borderwidth=5)
e.place(x=10, y=10)

result = e.get()



print(result)


mainloop()