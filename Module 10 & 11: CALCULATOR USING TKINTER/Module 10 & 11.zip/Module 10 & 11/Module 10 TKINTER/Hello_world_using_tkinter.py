# step1: import tkinter
from tkinter import *

# step2: gui interaction
window = Tk()  # step1: create a window

# step3: adding input
inp = Label(window, text="Hello world")  # step2: create a label
inp.pack()  # add the label to the window

# step4: main loop
window.mainloop()  # step3: run the main loop




