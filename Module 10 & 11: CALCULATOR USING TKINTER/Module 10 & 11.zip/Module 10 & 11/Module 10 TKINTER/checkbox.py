from tkinter import *

window = Tk()  # step1: create a window

window.title("Simple")  # step2: set the title of the window
window.geometry("500x200")  # set the size of the window


check_box_1 = IntVar()  # create a variable to store the value of the check box
check_box_2 = IntVar()  # create a variable to store the value of the check box
check_box_3 = IntVar()  # create a variable to store the value of the check box


chk_btn_1 = Checkbutton(window, text="Apple", onvalue=1, offvalue=0,height=2, width=10)  # create a check box
chk_btn_2 = Checkbutton(window, text="Banana", onvalue=1, offvalue=0,height=2, width=10)  # create a check box
chk_btn_3 = Checkbutton(window, text="Orange", onvalue=1, offvalue=0,height=2, width=10)  # create a check box



chk_btn_1.pack()  # add the check box to the window
chk_btn_2.pack()  # add the check box to the window
chk_btn_3.pack()  # add the check box to the window


print(check_box_1.get())  # print the value of the check box
print(check_box_2.get())  # print the value of the check box
print(check_box_3.get())  # print the value of the check box





mainloop()  # step3: run the main loop