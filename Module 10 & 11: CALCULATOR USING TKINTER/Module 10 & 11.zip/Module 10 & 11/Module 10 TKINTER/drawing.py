from tkinter import *


window = Tk()  # step1: create a window


c = Canvas(window, width=500, height=500)  # create a canvas
c.pack()  # add the canvas to the window


c.create_line(0,0,500,500, fill = "red", width=5, dash=(3,3))  # create a line from (0,0) to (500,500)
c.create_line(0,500,500,0, fill = "green", width=5, dash=(3,3)) # create a line from (0,500) to (500,0)
c.create_rectangle(100,100,400,400, fill = "lightblue", outline = "yellow", width=5)  # create a rectangle from (100,100) to (400,400)









mainloop()  # step3: run the main loop`