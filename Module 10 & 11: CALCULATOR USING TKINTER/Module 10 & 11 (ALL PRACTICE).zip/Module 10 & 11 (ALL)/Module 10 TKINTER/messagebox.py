from tkinter import *
import tkinter.messagebox as messagebox


# step2: gui interaction
window =Tk()  # step1: create a window
window.title("Simple")  # step2: set the title of the window
window.geometry("500x200")  # set the size of the window
# step3: adding input
a = messagebox.showwarning("Info", "Running out of time")  # show an info message box
ques = messagebox.askyesno("Weather", "Is it raining?")  # show an info message box

print(a)  # print the answer to the console
print(ques)  # print the answer to the console

if ques == True:  # if the answer is yes
    print("Take an umbrella")  # print the answer to the console
else:
    print("No need for an umbrella")











mainloop()  # step3: run the main loop