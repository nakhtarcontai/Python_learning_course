from tkinter import *


window =Tk()  # step1: create a window
window.title("Simple")  # step2: set the title of the window
window.geometry("500x200")  # set the size of the window

var = StringVar()  # create a string variable
entry_var = StringVar()  # create a string variable

def insert():
    result = entry_var.get()  # get the value of the entry box
    var.set(result)  # set the value of the message box to the value of the entry box

message = Message(window, textvariable = var, padx=12,pady=10, relief= RIDGE)  # create a message box
entry = Entry(window, textvariable = entry_var)  # create an entry box
# button = Button(window, text="Submit", command=lambda: var.set(entry_var.get()))  # create a button
button = Button(window, text="Submit", command=insert)  # create a button



message.pack()  # add the message box to the window
entry.pack()  # add the entry box to the window
button.pack()  # add the button to the window

mainloop()  # step3: run the main loop