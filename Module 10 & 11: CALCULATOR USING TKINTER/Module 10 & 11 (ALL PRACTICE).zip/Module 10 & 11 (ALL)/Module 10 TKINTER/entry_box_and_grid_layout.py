# step1: import tkinter
from tkinter import *

# step2: gui interaction
window = Tk()  # step1: create a window

# step3: adding input
window.title("Simple")  # step2: set the title of the window
window.geometry("500x200")  # set the size of the window

label1 = Label(window, text="Mail")  #create a label
label1.grid(row = 0, column = 1) # grid layout
label2 = Label(window, text="Password")  #create a label
label2.grid(row = 1, column = 1) # grid layout

e1 = Entry(window, width = 40, borderwidth = 5)  # create an entry box
e1.grid( row = 0, column = 2) # grid layout
e2 = Entry(window, width = 40, borderwidth = 5)  # create an entry box
e2.grid( row = 1, column = 2) # grid layout


# label1.pack()  # add the label to the window
# step4: main loop
window.mainloop()  # step3: run the main loop

