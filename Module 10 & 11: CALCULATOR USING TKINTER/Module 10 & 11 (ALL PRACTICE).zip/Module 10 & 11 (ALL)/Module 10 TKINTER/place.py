from tkinter import *

window = Tk()

window.title("Simple")  # step2: set the title of the window
window.geometry("500x200")  # set the size of the window


button = Button(window, text="LOGIN", bg = "red", fg = "white", width= "12", activebackground="green", activeforeground="white", ) # create a button
button.place(x=100, y=50)  # add the button to the window





mainloop()  # step3: run the main loop