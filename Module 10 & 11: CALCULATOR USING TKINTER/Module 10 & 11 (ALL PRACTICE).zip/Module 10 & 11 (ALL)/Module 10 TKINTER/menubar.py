from tkinter import *

window = Tk()  # step1: create a window

# step2: set the title of the window
window.title("Simple")  # step2: set the title of the window
window.geometry("500x200")  # set the size of the window
# step3: adding input
menu = Menu(window)  # create a menu
file = Menu(menu, tearoff=0)  # create a file menu
file.add_command(label="New")  # add a new command to the file menu
file.add_command(label="Open")  # add an open command to the file menu
file.add_command(label="Save")  # add a save command to the file menu
file.add_command(label="Save As")  # add a save as command to the file menu
file.add_separator()  # add a separator to the file menu
file.add_command(label="Exit", command=window.quit)  # add an exit command to the file menu







menu.add_cascade(label="File", menu=file)  # add the file menu to the menu bar
window.config(menu=menu)  # set the menu bar to the window

mainloop()