# step1: import tkinter
from tkinter import *

# step2: gui interaction
window = Tk()  # step1: create a window

# step3: adding input
window.title("Simple") # step2: set the title of the window
window.geometry("500x200")  # set the size of the window

label1 = Label(window, text="Label1", bg = "black", fg = "white")  #create a label
label1.pack(side = TOP, fill = X, expand = False)  # add the label to the window

label2 = Label(window, text="Label2", bg = "red", fg = "white")
label2.pack(side = LEFT, fill = Y, expand = True)  # add the label to the window

label3 = Label(window, text="Label3", bg = "Green", fg = "white")
label3.pack(side = RIGHT, fill = Y, expand = False)  # add the label to the window

label4 = Label(window, text="Label4", bg = "Blue", fg = "white")
label4.pack(side = BOTTOM, fill = X, expand = False)  # add the label to the window

# label1.pack()  # add the label to the window
# step4: main loop
window.mainloop()  # step3: run the main loop

