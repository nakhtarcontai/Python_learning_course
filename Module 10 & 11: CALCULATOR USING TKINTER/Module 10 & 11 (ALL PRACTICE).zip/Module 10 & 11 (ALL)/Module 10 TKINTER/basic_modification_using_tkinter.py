# step1: import tkinter
from tkinter import *

# step2: gui interaction
window = Tk()  # step1: create a window

# step3: adding input
window.title("Simple") # set the title of the window
window.geometry("300x200")  # set the size of the window
window.config(bg = "Yellow")  # set the background color of the window
frame1 = Frame(window, bg="red", width = 100, height= 100, cursor = "dot")  # create a frame
frame2 = Frame(window, bg="blue", width = 100, height= 100,  cursor="dotbox")  # create a frame
frame1.pack(side = TOP)  # add the frame to the window
frame2.pack(side = BOTTOM)  # add the frame to the window

# frame1 = Frame(window,  width = 100, height= 100, cursor = "dot", bg= "black")  # create a frame
# frame2 = Frame(window,  width = 100, height= 100,  cursor="dotbox", bg = "green")  # create a frame

button1 = Button(frame1, text="Button 1", bg="red", fg="white")  # create a button
button2 = Button(frame2, text="Button 2", bg="blue", fg="white")  # create a button
button3 = Button(frame1, text="Logged", bg="red", fg="White")  # create a button


# frame1.pack(side = TOP)  # add the frame to the window
# frame2.pack(side = BOTTOM)  # add the frame to the window
button1.pack()  # add the button to the frame
button2.pack()  # add the button to the frame
button3.pack()  # add the button to the frame
# step4: main loop
window.mainloop()  # step3: run the main loop
