# step1: import tkinter
from tkinter import *

# step2: gui interaction
window = Tk()  # step1: create a window
window.title("Simple")  # step2: set the title of the window
window.geometry("500x200")  # set the size of the window

# step3: adding input

# function to be called when button is clicked
def clicked():
    print("Button clicked")
button = Button(window, text="LOGIN", bg = "red", fg = "white", command= clicked, width= "12", activebackground="green", activeforeground="white", ) # create a button
button.pack()  # add the button to the window
# step4: main loop
window.mainloop()  # step3: run the main loop
